const help = (prefix) => { 
	return `  *🐊BOT BIANN🐊*

╭══─⊱ ❰ *FITUR BOT BIANN* ❱ ⊰─══➤
╠☞*${prefix}info
╠☞*${prefix}owner
╠☞*${prefix}donasi
╠☞*${prefix}repot
╠☞*${prefix}speed
■█■█■█■▰▱▰▱▰▱■█■█■█■

(════─⊱  ⸨ *BIANN BOT* ⸩  ⊰─════)

╭══─⊱ ❰ *MAKER MENU* ❱ ⊰─══➤
╠☞*${prefix}sticker
╠☞*${prefix}tsticker
╠☞*${prefix}toimg
╠☞*${prefix}wait
╠☞*${prefix}kbbi
╠☞*${prefix}imoji
╠☞*${prefix}url2img
╠☞*${prefix}playstore
╠☞*${prefix}wallpaperhd
╠☞*${prefix}ssweb
╠☞*${prefix}tts
╠☞*${prefix}ytmp4
╠☞*${prefix}ytmp3
■█■█■█■▰▱▰▱▰▱■█■█■█■

(════─⊱  ⸨ *BIANN BOT* ⸩  ⊰─════)

╭══─⊱ ❰ *MENU TEXT MAKER* ➤
╠☞*${prefix}firetext
╠☞*${prefix}text3d
╠☞*${prefix}textscreen
╠☞*${prefix}lionlogo
╠☞*${prefix}water
╠☞*${prefix}rtext
╠☞*${prefix}party
╠☞*${prefix}ninjalogo
╠☞*${prefix}stiltext
╠☞*${prefix}lovemake
╠☞*${prefix}textblue
╠☞*${prefix}textdark
╠☞*${prefix}tahta
╠☞*${prefix}thunder
■█■█■█■▰▱▰▱▰▱■█■█■█■

(════─⊱  ⸨ *BIANN BOT* ⸩  ⊰─════)

╭══─⊱ ❰ *FUN MENU* ❱ ⊰─══➤
╠☞*${prefix}artinama
╠☞*${prefix}truth
╠☞*${prefix}dare
╠☞*${prefix}tebakgambar
╠☞*${prefix}family100
╠☞*${prefix}caklontong
╠☞*${prefix}game
╠☞*${prefix}primbonjodoh
╠☞*${prefix}ramaljodoh
╠☞*${prefix}ramaljadian
╠☞*${prefix}mlherolist
╠☞*${prefix}bucin
╠☞*${prefix}persengay
╠☞*${prefix}ramalhp
╠☞*${prefix}cekjodoh
■█■█■█■▰▱▰▱▰▱■█■█■█■

(════─⊱  ⸨ *BIANN BOT* ⸩  ⊰─════)

╭══─⊱ ❰ *INFO MENU* ❱ ⊰─══➤
╠☞*${prefix}infogc
╠☞*${prefix}groupinfo
╠☞*${prefix}lirik
╠☞*${prefix}quotes
╠☞*${prefix}cerpen
╠☞*${prefix}chord
╠☞*${prefix}wiki
╠☞*${prefix}brainly
╠☞*${prefix}resepmakanan
╠☞*${prefix}map
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙*GROUP MENU*
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}add
▋┋*${prefix}kick
▋┋*${prefix}promote
▋┋*${prefix}demote
▋┋*${prefix}setname
▋┋*${prefix}setdesc
▋┋*${prefix}welcome
▋┋*${prefix}simih
▋┋*${prefix}group
▋┋*${prefix}tagme
▋┋*${prefix}hidetag
▋┋*${prefix}tag
▋┋*${prefix}tagall
▋┋*${prefix}fitnah
▋┋*${prefix}infogc
▋┋*${prefix}groupinfo
▋┋*${prefix}linkgroup
▋┋*${prefix}listadmins
▋┋*${prefix}edotense
▋┋*${prefix}kudeta
■█■█■█■▰▱▰▱▰▱■█■█■█■

(════─⊱  ⸨ *BIANN BOT* ⸩  ⊰─════)

╭══─⊱ ❰ *KERANG MENU* ❱ ⊰─══➤
╠☞*${prefix}apakah
╠☞*${prefix}kapankah
╠☞*${prefix}bisakah
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙*OTHER MENU*
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}blosklist
▋┋*${prefix}say
▋┋*${prefix}hilih
▋┋*${prefix}testime
▋┋*${prefix}delete
▋┋*${prefix}shorturl
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙*OWNER MENU*
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}bc -promosi*
▋┋*${prefix}ban -banned
▋┋*${prefix}block -blok
▋┋*${prefix}unblok
▋┋*${prefix}clearall
▋┋*${prefix}clone
▋┋*${prefix}getses
▋┋*${prefix}setpp
▋┋*${prefix}leave

┏━━━━━━━━━━━━━━━━━━━━

┃          𝗗𝗢𝗡𝗔𝗦𝗜  

┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ 𝗗𝗢𝗡𝗔𝗦𝗜 𝗕𝗢𝗦𝗤𝗨𝗘 ❉⊰━━✿
┃  
┣━⊱ *SAWERIA*
┣⊱ https://saweria.co/BiannBot
┣━⊱ *PULSA*
┣⊱ 082134932230
┃
┃*~MAKASIH YA YANG UDAH DONASI🥰*┏━━━━━━━━━━━━━━━━━━━━
━━━━━━━━━━━━━━━


═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡
*(•♛•)─•••──ೇุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุ──────﹒ׂׂૢ་༘࿐ೢִֶָ──╮*
*▄▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▄*        
    *┏ೋ┉━┉ೋ✧ೋ┉━┉ೋ┓*
      *BIANN BOT*
    *┗ೋ┉━┉ೋ✧ೋ┉━┉ೋ┛*
*▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀*       
   ۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈ٜٜٜٜٜٜٜ͡҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ©`

  
}
exports.help = help
